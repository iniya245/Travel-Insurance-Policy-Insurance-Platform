import { FormEvent, ReactNode, useEffect, useMemo, useState } from "react";
import {
  ArrowRight,
  BadgeCheck,
  BarChart3,
  CalendarDays,
  Check,
  ChevronRight,
  CircleAlert,
  Clock3,
  FileCheck2,
  FileText,
  Headphones,
  LayoutDashboard,
  LockKeyhole,
  LogOut,
  MapPin,
  Menu,
  Plane,
  Plus,
  RefreshCw,
  Search,
  Shield,
  ShieldCheck,
  Sparkles,
  TicketCheck,
  TrendingUp,
  UserPlus,
  Users,
  WalletCards,
  X,
} from "lucide-react";
import "./index.css";
import { calculatePremium } from "@shared/travel";

type Page = "home" | "register" | "login" | "admin-login" | "dashboard" | "apply" | "policies" | "claim" | "renewal" | "admin" | "admin-users" | "admin-policies" | "admin-claims" | "success";
type Session = { role: "user" | "admin"; userId?: string; name?: string } | null;
type User = { id: string; name: string; email: string; phone: string; password: string; joined: string };
type Policy = { id: string; userId: string; name: string; destination: string; travelDate: string; duration: number; premium: number; status: "Active" | "Expired" };
type Claim = { id: string; userId: string; policyId: string; reason: string; status: "Pending" | "Approved" | "Rejected"; submitted: string };
type Renewal = { id: string; userId: string; policyId: string; status: "Pending" | "Approved"; submitted: string };
type Store = { users: User[]; policies: Policy[]; claims: Claim[]; renewals: Renewal[] };

const STORE_KEY = "travel-insurance-platform-store-v1";
const SESSION_KEY = "travel-insurance-platform-session-v1";
const today = () => new Date().toISOString().slice(0, 10);
const uid = (prefix: string) => `${prefix}-${Math.random().toString(36).slice(2, 8).toUpperCase()}`;

const defaultStore: Store = {
  users: [],
  policies: [],
  claims: [],
  renewals: [],
};

function readStore(): Store {
  try {
    const stored = localStorage.getItem(STORE_KEY);
    return stored ? JSON.parse(stored) : defaultStore;
  } catch {
    return defaultStore;
  }
}

function readSession(): Session {
  try {
    const stored = localStorage.getItem(SESSION_KEY);
    return stored ? JSON.parse(stored) : null;
  } catch {
    return null;
  }
}

function App() {
  const [page, setPage] = useState<Page>(() => (window.location.pathname.slice(1) as Page) || "home");
  const [store, setStore] = useState<Store>(readStore);
  const [session, setSession] = useState<Session>(readSession);
  const [toast, setToast] = useState<string | null>(null);
  const [mobileNav, setMobileNav] = useState(false);

  useEffect(() => localStorage.setItem(STORE_KEY, JSON.stringify(store)), [store]);
  useEffect(() => {
    if (session) localStorage.setItem(SESSION_KEY, JSON.stringify(session));
    else localStorage.removeItem(SESSION_KEY);
  }, [session]);
  useEffect(() => {
    const onPop = () => setPage((window.location.pathname.slice(1) as Page) || "home");
    window.addEventListener("popstate", onPop);
    return () => window.removeEventListener("popstate", onPop);
  }, []);
  useEffect(() => {
    if (!toast) return;
    const timeout = window.setTimeout(() => setToast(null), 3600);
    return () => window.clearTimeout(timeout);
  }, [toast]);

  const navigate = (next: Page) => {
    const protectedUser: Page[] = ["dashboard", "apply", "policies", "claim", "renewal"];
    const protectedAdmin: Page[] = ["admin", "admin-users", "admin-policies", "admin-claims"];
    if (protectedUser.includes(next) && session?.role !== "user") next = "login";
    if (protectedAdmin.includes(next) && session?.role !== "admin") next = "admin-login";
    window.history.pushState({}, "", next === "home" ? "/" : `/${next}`);
    setPage(next);
    setMobileNav(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const signOut = () => {
    setSession(null);
    setToast("You have been safely signed out.");
    navigate("home");
  };

  const currentUser = session?.role === "user" ? store.users.find((user) => user.id === session.userId) : undefined;

  const updateStore = (patch: Partial<Store>) => setStore((current) => ({ ...current, ...patch }));

  return (
    <div className="app-root">
      {page === "home" && <PublicHeader session={session} navigate={navigate} signOut={signOut} mobileNav={mobileNav} setMobileNav={setMobileNav} />}
      {page !== "home" && <AppHeader session={session} navigate={navigate} signOut={signOut} mobileNav={mobileNav} setMobileNav={setMobileNav} />}
      <main>
        {page === "home" && <HomePage navigate={navigate} />}
        {page === "register" && <RegisterPage navigate={navigate} store={store} updateStore={updateStore} setSession={setSession} setToast={setToast} />}
        {page === "login" && <LoginPage navigate={navigate} store={store} setSession={setSession} setToast={setToast} />}
        {page === "admin-login" && <AdminLoginPage navigate={navigate} setSession={setSession} setToast={setToast} />}
        {page === "dashboard" && currentUser && <DashboardPage user={currentUser} store={store} navigate={navigate} />}
        {page === "apply" && currentUser && <ApplyPage user={currentUser} store={store} updateStore={updateStore} navigate={navigate} setToast={setToast} />}
        {page === "policies" && currentUser && <PoliciesPage user={currentUser} store={store} navigate={navigate} />}
        {page === "claim" && currentUser && <ClaimPage user={currentUser} store={store} updateStore={updateStore} navigate={navigate} setToast={setToast} />}
        {page === "renewal" && currentUser && <RenewalPage user={currentUser} store={store} updateStore={updateStore} navigate={navigate} setToast={setToast} />}
        {page === "success" && <SuccessPage navigate={navigate} />}
        {page === "admin" && session?.role === "admin" && <AdminDashboard store={store} navigate={navigate} />}
        {page === "admin-users" && session?.role === "admin" && <AdminUsers store={store} navigate={navigate} />}
        {page === "admin-policies" && session?.role === "admin" && <AdminPolicies store={store} navigate={navigate} />}
        {page === "admin-claims" && session?.role === "admin" && <AdminClaims store={store} updateStore={updateStore} navigate={navigate} setToast={setToast} />}
        {!session && ["dashboard", "apply", "policies", "claim", "renewal"].includes(page) && <LoginPage navigate={navigate} store={store} setSession={setSession} setToast={setToast} />}
        {!session && ["admin", "admin-users", "admin-policies", "admin-claims"].includes(page) && <AdminLoginPage navigate={navigate} setSession={setSession} setToast={setToast} />}
      </main>
      {page === "home" && <SiteFooter navigate={navigate} />}
      {toast && <div className="toast"><Check size={17} /> {toast}<button onClick={() => setToast(null)}><X size={15} /></button></div>}
    </div>
  );
}

function PublicHeader({ session, navigate, signOut, mobileNav, setMobileNav }: HeaderProps) {
  return <header className="site-header public-header"><Logo navigate={navigate} /><button className="mobile-menu" onClick={() => setMobileNav(!mobileNav)}>{mobileNav ? <X /> : <Menu />}</button><nav className={mobileNav ? "nav-open" : ""}><a onClick={() => navigate("home")}>Home</a><a onClick={() => navigate("home")}>How it works</a><a onClick={() => navigate("home")}>Coverage</a><span className="nav-divider" />{session?.role === "user" ? <button className="nav-pill" onClick={() => navigate("dashboard")}>Open dashboard <ArrowRight size={15} /></button> : <><a onClick={() => navigate("login")}>Log in</a><button className="nav-pill" onClick={() => navigate("register")}>Get started <ArrowRight size={15} /></button></>}</nav></header>;
}

type HeaderProps = { session: Session; navigate: (page: Page) => void; signOut: () => void; mobileNav: boolean; setMobileNav: (value: boolean) => void };
function AppHeader({ session, navigate, signOut, mobileNav, setMobileNav }: HeaderProps) {
  const admin = session?.role === "admin";
  return <header className="site-header app-header"><Logo navigate={navigate} /><button className="mobile-menu" onClick={() => setMobileNav(!mobileNav)}>{mobileNav ? <X /> : <Menu />}</button><nav className={mobileNav ? "nav-open" : ""}>{admin ? <><a className="active" onClick={() => navigate("admin")}>Admin overview</a><a onClick={() => navigate("admin-users")}>Users</a><a onClick={() => navigate("admin-policies")}>Policies</a><a onClick={() => navigate("admin-claims")}>Claims</a></> : <><a className="active" onClick={() => navigate("dashboard")}>Dashboard</a><a onClick={() => navigate("policies")}>My policies</a><a onClick={() => navigate("claim")}>Claims</a></>}<button className="header-signout" onClick={signOut}><LogOut size={16} /> Sign out</button></nav></header>;
}
function Logo({ navigate }: { navigate: (page: Page) => void }) { return <button className="logo" onClick={() => navigate("home")}><span className="logo-icon"><ShieldCheck size={20} /></span><span>Travel Insurance<span className="logo-sub">Policy Issuance Platform</span></span></button>; }

function HomePage({ navigate }: { navigate: (page: Page) => void }) {
  return <>
    <section className="hero-section page-container">
      <div className="hero-copy"><div className="eyebrow"><span className="eyebrow-dot" /> TRAVEL PROTECTION, SIMPLIFIED</div><h1>Travel further.<br /><span>Feel protected.</span></h1><p className="hero-lead">A complete digital travel insurance experience built for modern journeys. Apply for a policy, manage your cover and request support from one calm, clear platform.</p><div className="hero-actions"><button className="button button-primary" onClick={() => navigate("register")}>Get started <ArrowRight size={18} /></button><button className="button button-secondary" onClick={() => navigate("login")}>I already have an account</button></div><div className="hero-trust"><span><LockKeyhole size={14} /> Secure session login</span><span><BadgeCheck size={14} /> Instant premium estimate</span></div></div>
      <div className="hero-visual"><div className="hero-orbit orbit-one" /><div className="hero-orbit orbit-two" /><div className="hero-sun"><Sparkles size={22} /></div><div className="hero-card route-card"><div className="card-label">YOUR NEXT ADVENTURE</div><div className="route-title">Anywhere worth going.</div><div className="route"><span>DEL</span><i /><Plane size={18} /><span>↗</span></div><div className="route-caption">Flexible cover · Human support</div></div><div className="hero-mountain mountain-back" /><div className="hero-mountain mountain-front" /><div className="hero-float"><span className="float-check"><Check size={13} /></span><span><b>Policy ready</b><small>in just a few minutes</small></span></div></div>
    </section>
    <section className="stat-ribbon"><div><strong>01</strong><h3>Apply in minutes</h3><p>Enter your trip details and get a clear premium instantly.</p></div><div><strong>02</strong><h3>Stay in control</h3><p>Manage policies, claims and renewals from your dashboard.</p></div><div><strong>03</strong><h3>Travel lighter</h3><p>Simple workflows designed around the way people travel.</p></div></section>
    <section className="story-section page-container"><div className="section-kicker">A BETTER WAY TO BE COVERED</div><div className="story-grid"><div><h2>Good protection should feel <em>simple.</em></h2></div><div><p>Travel Insurance Policy Issuance Platform digitizes the complete travel insurance process — from first application to claims and renewal — without the paperwork maze.</p><button className="text-button" onClick={() => navigate("register")}>Explore the platform <ArrowRight size={17} /></button></div></div><div className="story-cards"><div><Shield size={25} /><h3>Clear by design</h3><p>No confusing jargon. See what you are covered for and what your premium means.</p></div><div><Headphones size={25} /><h3>Support when it counts</h3><p>Submit a claim or renewal request in a few focused steps.</p></div><div><TrendingUp size={25} /><h3>Built to scale</h3><p>A capstone-ready system with a clean path to production deployment.</p></div></div></section>
  </>;
}

function AuthLayout({ children, title, description, badge }: { children: ReactNode; title: ReactNode; description: string; badge: string }) { return <section className="auth-shell page-container"><div className="auth-aside"><div className="eyebrow"><span className="eyebrow-dot" /> {badge}</div><h1>{title}</h1><p>{description}</p><div className="aside-note"><ShieldCheck size={20} /><span><b>Your travel, protected.</b><small>Secure, simple, and ready when you are.</small></span></div></div><div className="auth-card">{children}</div></section>; }

function RegisterPage({ navigate, store, updateStore, setSession, setToast }: { navigate: (page: Page) => void; store: Store; updateStore: (patch: Partial<Store>) => void; setSession: (session: Session) => void; setToast: (message: string) => void }) {
  const [form, setForm] = useState({ name: "", email: "", phone: "", password: "" });
  const [error, setError] = useState("");
  const submit = (event: FormEvent) => { event.preventDefault(); if (!form.name || !form.email || !form.phone || form.password.length < 6) return setError("Complete every field. Password must be at least 6 characters."); if (store.users.some((user) => user.email.toLowerCase() === form.email.toLowerCase())) return setError("An account with this email already exists."); const user = { ...form, id: uid("USR"), joined: today() }; updateStore({ users: [...store.users, user] }); setSession({ role: "user", userId: user.id, name: user.name }); setToast("Account created. Welcome to the platform."); navigate("dashboard"); };
  return <AuthLayout badge="CREATE YOUR ACCOUNT" title={<>Your journey<br /><span>starts here.</span></>} description="Protect upcoming trips, access your policies and keep every request in one organized place."><div className="card-kicker">NEW CUSTOMER</div><h2>Join the platform</h2><p className="auth-helper">Already registered? <button onClick={() => navigate("login")}>Log in</button></p><form onSubmit={submit} className="form-stack"><Field label="Full name" value={form.name} onChange={(value) => setForm({ ...form, name: value })} placeholder="Alex Morgan" /><Field label="Email address" type="email" value={form.email} onChange={(value) => setForm({ ...form, email: value })} placeholder="alex@example.com" /><Field label="Phone number" value={form.phone} onChange={(value) => setForm({ ...form, phone: value })} placeholder="+91 98765 43210" /><Field label="Password" type="password" value={form.password} onChange={(value) => setForm({ ...form, password: value })} placeholder="At least 6 characters" />{error && <FormError>{error}</FormError>}<button className="button button-primary wide-button" type="submit">Create my account <ArrowRight size={18} /></button></form></AuthLayout>;
}

function LoginPage({ navigate, store, setSession, setToast }: { navigate: (page: Page) => void; store: Store; setSession: (session: Session) => void; setToast: (message: string) => void }) {
  const [email, setEmail] = useState(""); const [password, setPassword] = useState(""); const [error, setError] = useState("");
  const submit = (event: FormEvent) => { event.preventDefault(); const user = store.users.find((item) => item.email.toLowerCase() === email.toLowerCase() && item.password === password); if (!user) return setError("Login failed. Check your email and password."); setSession({ role: "user", userId: user.id, name: user.name }); setToast(`Welcome back, ${user.name.split(" ")[0]}.`); navigate("dashboard"); };
  return <AuthLayout badge="WELCOME BACK" title={<>Ready for<br /><span>takeoff?</span></>} description="Log in to manage your cover, submit a claim or request a renewal for your next journey."><div className="card-kicker">ACCOUNT LOGIN</div><h2>Log in to your account</h2><p className="auth-helper">New here? <button onClick={() => navigate("register")}>Create an account</button></p><form onSubmit={submit} className="form-stack"><Field label="Email address" type="email" value={email} onChange={setEmail} placeholder="alex@example.com" /><Field label="Password" type="password" value={password} onChange={setPassword} placeholder="Your password" />{error && <FormError>{error}</FormError>}<button className="button button-primary wide-button" type="submit">Log in <ArrowRight size={18} /></button></form><div className="auth-divider"><span>or</span></div><button className="admin-entry" onClick={() => navigate("admin-login")}><Shield size={16} /> Administrator sign in</button></AuthLayout>;
}

function AdminLoginPage({ navigate, setSession, setToast }: { navigate: (page: Page) => void; setSession: (session: Session) => void; setToast: (message: string) => void }) {
  const [username, setUsername] = useState(""); const [password, setPassword] = useState(""); const [error, setError] = useState("");
  const submit = (event: FormEvent) => { event.preventDefault(); if (username !== "admin" || password !== "admin123") return setError("Invalid admin login. Try the demo credentials."); setSession({ role: "admin", name: "Administrator" }); setToast("Administrator access granted."); navigate("admin"); };
  return <AuthLayout badge="OPERATIONS CONSOLE" title={<>Keep every<br /><span>journey moving.</span></>} description="Review users, policies and claims from the Travel Insurance Policy Issuance Platform administration workspace."><div className="card-kicker">ADMIN LOGIN</div><h2>Administrator sign in</h2><p className="auth-helper">Demo access is configured for this capstone platform.</p><form onSubmit={submit} className="form-stack"><Field label="Username" value={username} onChange={setUsername} placeholder="admin" /><Field label="Password" type="password" value={password} onChange={setPassword} placeholder="admin123" />{error && <FormError>{error}</FormError>}<button className="button button-primary wide-button" type="submit">Open admin dashboard <ArrowRight size={18} /></button></form><button className="back-link" onClick={() => navigate("login")}>← Back to customer login</button></AuthLayout>;
}

function Field({ label, value, onChange, placeholder, type = "text" }: { label: string; value: string; onChange: (value: string) => void; placeholder: string; type?: string }) { return <label className="field"><span>{label}</span><input type={type} value={value} required onChange={(event) => onChange(event.target.value)} placeholder={placeholder} /></label>; }
function FormError({ children }: { children: ReactNode }) { return <div className="form-error"><CircleAlert size={15} /> {children}</div>; }

function DashboardPage({ user, store, navigate }: { user: User; store: Store; navigate: (page: Page) => void }) {
  const policies = store.policies.filter((policy) => policy.userId === user.id); const claims = store.claims.filter((claim) => claim.userId === user.id); const pending = claims.filter((claim) => claim.status === "Pending").length;
  return <section className="dashboard-shell page-container"><div className="section-heading"><div><div className="eyebrow">YOUR TRAVEL DESK</div><h1>Hello, {user.name.split(" ")[0]}.</h1><p>Everything you need for a more confident journey.</p></div><button className="button button-primary" onClick={() => navigate("apply")}><Plus size={17} /> New policy</button></div><div className="metric-grid"><Metric icon={<ShieldCheck />} value={policies.length} label="Active policies" /><Metric icon={<TicketCheck />} value={claims.length} label="Total claims" /><Metric icon={<Clock3 />} value={pending} label="Pending reviews" /><Metric icon={<WalletCards />} value={policies.reduce((sum, policy) => sum + policy.premium, 0) ? `₹${policies.reduce((sum, policy) => sum + policy.premium, 0)}` : "₹0"} label="Premium paid" /></div><div className="dashboard-grid"><div className="welcome-panel"><div className="panel-kicker">TRAVEL PROTECTION, AT A GLANCE</div><h2>Your next adventure<br /><em>is worth protecting.</em></h2><p>Apply for a policy, then use this dashboard to manage your coverage and requests all the way through your journey.</p><button className="text-button light" onClick={() => navigate("apply")}>Protect a new trip <ArrowRight size={17} /></button><div className="panel-stamp"><Sparkles size={14} /> Designed for calm travel</div></div><div className="quick-panel"><div className="panel-title-row"><div><div className="panel-kicker">QUICK ACTIONS</div><h3>What would you like to do?</h3></div><LayoutDashboard size={21} /></div><QuickAction icon={<Plus />} title="Apply for a new policy" description="Get cover for your next destination." onClick={() => navigate("apply")} /><QuickAction icon={<FileText />} title="View my policies" description="Review your active travel cover." onClick={() => navigate("policies")} /><QuickAction icon={<TicketCheck />} title="Claim insurance" description="Submit a support request." onClick={() => navigate("claim")} /><QuickAction icon={<RefreshCw />} title="Policy renewal" description="Keep your protection going." onClick={() => navigate("renewal")} /></div></div><div className="recent-section"><div className="section-title-row"><div><div className="panel-kicker">RECENT ACTIVITY</div><h2>Your policies</h2></div><button className="text-button" onClick={() => navigate("policies")}>View all <ArrowRight size={16} /></button></div>{policies.length ? <div className="mini-table">{policies.slice(0, 3).map((policy) => <div className="mini-row" key={policy.id}><div className="mini-icon"><Plane size={17} /></div><div className="mini-main"><b>#{policy.id}</b><span>{policy.destination} · {policy.travelDate}</span></div><strong>₹{policy.premium}</strong><span className="status-chip active">{policy.status}</span><ChevronRight size={17} className="muted-icon" /></div>)}</div> : <EmptyState icon={<Plane />} title="No policies yet" description="Your next adventure deserves a little extra confidence." action="Apply for a policy" onClick={() => navigate("apply")} />}</div></section>;
}
function Metric({ icon, value, label }: { icon: ReactNode; value: string | number; label: string }) { return <div className="metric-card"><div className="metric-icon">{icon}</div><strong>{value}</strong><span>{label}</span></div>; }
function QuickAction({ icon, title, description, onClick }: { icon: ReactNode; title: string; description: string; onClick: () => void }) { return <button className="quick-action" onClick={onClick}><span className="quick-icon">{icon}</span><span><b>{title}</b><small>{description}</small></span><ArrowRight size={16} /></button>; }

function ApplyPage({ user, store, updateStore, navigate, setToast }: { user: User; store: Store; updateStore: (patch: Partial<Store>) => void; navigate: (page: Page) => void; setToast: (message: string) => void }) {
  const [form, setForm] = useState({ name: user.name, destination: "", travelDate: "", duration: "" }); const [error, setError] = useState(""); const premium = calculatePremium(Number(form.duration || 0));
  const submit = (event: FormEvent) => { event.preventDefault(); const duration = Number(form.duration); if (!form.name || !form.destination || !form.travelDate || !duration || duration < 1) return setError("Complete the travel details with a valid duration."); const policy = { id: uid("POL"), userId: user.id, name: form.name, destination: form.destination, travelDate: form.travelDate, duration, premium, status: "Active" as const }; updateStore({ policies: [policy, ...store.policies] }); setToast(`Policy #${policy.id} issued successfully.`); navigate("success"); };
  return <section className="workflow-shell page-container"><BackLink onClick={() => navigate("dashboard")} label="Dashboard" /><div className="section-heading compact-heading"><div><div className="eyebrow">NEW TRAVEL COVER</div><h1>Plan with confidence.</h1><p>Your premium is calculated at <b>₹100 per travel day.</b></p></div><div className="step-indicator"><span className="step-active">01</span><i /><span>02</span><i /><span>03</span></div></div><div className="workflow-grid"><div className="form-card-large"><div className="card-kicker">TRIP DETAILS</div><h2>Where are you headed?</h2><p className="form-intro">Tell us about your journey and we will prepare your cover.</p><form onSubmit={submit} className="form-stack"><div className="two-col"><Field label="Name on policy" value={form.name} onChange={(value) => setForm({ ...form, name: value })} placeholder="Your full name" /><Field label="Destination" value={form.destination} onChange={(value) => setForm({ ...form, destination: value })} placeholder="e.g. Singapore" /></div><div className="two-col"><Field label="Travel date" type="date" value={form.travelDate} onChange={(value) => setForm({ ...form, travelDate: value })} placeholder="Select a date" /><Field label="Travel duration (days)" type="number" value={form.duration} onChange={(value) => setForm({ ...form, duration: value })} placeholder="7" /></div>{error && <FormError>{error}</FormError>}<button className="button button-primary" type="submit">Calculate & issue policy <ArrowRight size={18} /></button></form></div><div className="estimate-card"><div className="estimate-top"><span className="estimate-icon"><CircleDollarSignIcon /></span><span>LIVE ESTIMATE</span></div><h3>Simple, transparent pricing.</h3><p>Premium = travel duration × ₹100. No hidden calculations.</p><div className="estimate-line"><span>{form.duration || "0"} travel days</span><b>₹{premium}</b></div><div className="estimate-total"><span>Estimated premium</span><strong>₹{premium}</strong></div><div className="estimate-note"><Check size={14} /> Your policy will be stored securely</div></div></div></section>;
}
function CircleDollarSignIcon() { return <span className="rupee-symbol">₹</span>; }
function BackLink({ onClick, label }: { onClick: () => void; label: string }) { return <button className="back-link" onClick={onClick}>← {label}</button>; }

function PoliciesPage({ user, store, navigate }: { user: User; store: Store; navigate: (page: Page) => void }) { const policies = store.policies.filter((policy) => policy.userId === user.id); return <section className="page-container table-page"><div className="section-heading"><div><div className="eyebrow">YOUR COVER</div><h1>My policies</h1><p>A clear view of every trip you have protected.</p></div><button className="button button-primary" onClick={() => navigate("apply")}><Plus size={17} /> New policy</button></div>{policies.length ? <div className="data-table-wrap"><table><thead><tr><th>Policy</th><th>Destination</th><th>Travel date</th><th>Duration</th><th>Premium</th><th>Status</th></tr></thead><tbody>{policies.map((policy) => <tr key={policy.id}><td><b>#{policy.id}</b><small>{policy.name}</small></td><td><span className="destination-cell"><MapPin size={14} /> {policy.destination}</span></td><td>{policy.travelDate}</td><td>{policy.duration} days</td><td><b>₹{policy.premium}</b></td><td><span className="status-chip active">{policy.status}</span></td></tr>)}</tbody></table></div> : <EmptyState icon={<Plane />} title="No policies yet" description="Your next adventure deserves a little extra confidence." action="Apply for a policy" onClick={() => navigate("apply")} />}</section>; }

function ClaimPage({ user, store, updateStore, navigate, setToast }: { user: User; store: Store; updateStore: (patch: Partial<Store>) => void; navigate: (page: Page) => void; setToast: (message: string) => void }) { const policies = store.policies.filter((policy) => policy.userId === user.id); const [policyId, setPolicyId] = useState(""); const [reason, setReason] = useState(""); const [error, setError] = useState(""); const submit = (event: FormEvent) => { event.preventDefault(); if (!policyId || !reason) return setError("Select a policy and claim reason."); const claim = { id: uid("CLM"), userId: user.id, policyId, reason, status: "Pending" as const, submitted: today() }; updateStore({ claims: [claim, ...store.claims] }); setToast(`Claim #${claim.id} submitted successfully.`); navigate("success"); }; return <section className="workflow-shell page-container"><BackLink onClick={() => navigate("dashboard")} label="Dashboard" /><div className="section-heading compact-heading"><div><div className="eyebrow">SUPPORT WHEN IT COUNTS</div><h1>Submit a claim.</h1><p>Tell us what happened. Your request will be reviewed by the administrator.</p></div></div><div className="form-card-large narrow-form"><div className="card-kicker">CLAIM REQUEST</div><h2>What happened?</h2><form onSubmit={submit} className="form-stack"><label className="field"><span>Policy ID</span><select value={policyId} onChange={(event) => setPolicyId(event.target.value)} required><option value="">Select a policy</option>{policies.map((policy) => <option key={policy.id} value={policy.id}>#{policy.id} · {policy.destination} · {policy.travelDate}</option>)}</select></label><label className="field"><span>Claim reason</span><select value={reason} onChange={(event) => setReason(event.target.value)} required><option value="">Select a reason</option><option>Medical Emergency</option><option>Trip Cancellation</option><option>Lost Baggage</option><option>Accident</option></select></label>{error && <FormError>{error}</FormError>}<div className="info-banner"><ShieldCheck size={19} /><span><b>Your request is secure</b><small>Claims start as Pending and can be reviewed by the administrator.</small></span></div><button className="button button-primary" type="submit">Submit claim request <ArrowRight size={18} /></button></form></div></section>; }

function RenewalPage({ user, store, updateStore, navigate, setToast }: { user: User; store: Store; updateStore: (patch: Partial<Store>) => void; navigate: (page: Page) => void; setToast: (message: string) => void }) { const policies = store.policies.filter((policy) => policy.userId === user.id); const [policyId, setPolicyId] = useState(""); const [error, setError] = useState(""); const submit = (event: FormEvent) => { event.preventDefault(); if (!policyId) return setError("Select a policy to renew."); const renewal = { id: uid("REN"), userId: user.id, policyId, status: "Pending" as const, submitted: today() }; updateStore({ renewals: [renewal, ...store.renewals] }); setToast(`Renewal request #${renewal.id} submitted.`); navigate("success"); }; return <section className="workflow-shell page-container"><BackLink onClick={() => navigate("dashboard")} label="Dashboard" /><div className="section-heading compact-heading"><div><div className="eyebrow">KEEP GOING</div><h1>Renew your cover.</h1><p>Send a renewal request for an existing policy.</p></div></div><div className="form-card-large narrow-form"><div className="card-kicker">RENEWAL REQUEST</div><h2>Which policy should continue?</h2><form onSubmit={submit} className="form-stack"><label className="field"><span>Policy ID</span><select value={policyId} onChange={(event) => setPolicyId(event.target.value)} required><option value="">Select a policy</option>{policies.map((policy) => <option key={policy.id} value={policy.id}>#{policy.id} · {policy.destination} · {policy.travelDate}</option>)}</select></label>{error && <FormError>{error}</FormError>}<div className="info-banner"><RefreshCw size={19} /><span><b>Administrator review</b><small>Your renewal request will stay Pending until reviewed.</small></span></div><button className="button button-primary" type="submit">Request renewal <ArrowRight size={18} /></button></form></div></section>; }

function SuccessPage({ navigate }: { navigate: (page: Page) => void }) { return <section className="success-screen page-container"><div className="success-check"><Check size={34} /></div><div className="eyebrow">REQUEST RECEIVED</div><h1>You're all set.</h1><p>Your request has been recorded successfully. You can return to your dashboard to keep managing your journey.</p><button className="button button-primary" onClick={() => navigate("dashboard")}>Return to dashboard <ArrowRight size={18} /></button></section>; }

function AdminDashboard({ store, navigate }: { store: Store; navigate: (page: Page) => void }) { const pending = store.claims.filter((claim) => claim.status === "Pending").length; return <section className="admin-shell page-container"><div className="section-heading"><div><div className="eyebrow">OPERATIONS CONSOLE</div><h1>Good morning, admin.</h1><p>A live overview of the Travel Insurance Policy Issuance Platform.</p></div><span className="admin-badge"><Shield size={15} /> Administrator</span></div><div className="metric-grid admin-metrics"><Metric icon={<Users />} value={store.users.length} label="Registered users" /><Metric icon={<ShieldCheck />} value={store.policies.length} label="Policies issued" /><Metric icon={<TicketCheck />} value={store.claims.length} label="Total claims" /><Metric icon={<Clock3 />} value={pending} label="Claims pending" /></div><div className="admin-overview-grid"><div className="admin-welcome"><div className="panel-kicker">PLATFORM HEALTH</div><h2>Keep every journey<br /><em>moving forward.</em></h2><p>Use the operations console to review registered users, issued policies and customer claims.</p><div className="health-row"><span><i className="health-dot" /> All systems operational</span><span>Updated just now</span></div></div><div className="admin-links"><AdminLink icon={<Users />} number="01" title="View all users" description="Browse registered customer accounts." onClick={() => navigate("admin-users")} /><AdminLink icon={<FileCheck2 />} number="02" title="View all policies" description="Review issued policies across the platform." onClick={() => navigate("admin-policies")} /><AdminLink icon={<TicketCheck />} number="03" title="Review all claims" description="Update requests and their statuses." onClick={() => navigate("admin-claims")} /></div></div></section>; }
function AdminLink({ icon, number, title, description, onClick }: { icon: ReactNode; number: string; title: string; description: string; onClick: () => void }) { return <button className="admin-link-card" onClick={onClick}><span className="admin-link-icon">{icon}</span><span className="admin-link-number">{number}</span><span className="admin-link-copy"><b>{title}</b><small>{description}</small></span><ArrowRight size={17} /></button>; }

function AdminUsers({ store, navigate }: { store: Store; navigate: (page: Page) => void }) { return <AdminTablePage title="All users" eyebrow="ADMIN · DIRECTORY" description="Every registered customer account." navigate={navigate}>{store.users.length ? <div className="data-table-wrap"><table><thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Joined</th></tr></thead><tbody>{store.users.map((user) => <tr key={user.id}><td><b>#{user.id}</b></td><td><b>{user.name}</b></td><td>{user.email}</td><td>{user.phone}</td><td>{user.joined}</td></tr>)}</tbody></table></div> : <EmptyState icon={<Users />} title="No users yet" description="New customer accounts will appear here." />}</AdminTablePage>; }
function AdminPolicies({ store, navigate }: { store: Store; navigate: (page: Page) => void }) { return <AdminTablePage title="All policies" eyebrow="ADMIN · COVERAGE" description="Every issued travel policy across the platform." navigate={navigate}>{store.policies.length ? <div className="data-table-wrap"><table><thead><tr><th>Policy</th><th>Customer</th><th>Destination</th><th>Travel date</th><th>Duration</th><th>Premium</th></tr></thead><tbody>{store.policies.map((policy) => { const user = store.users.find((item) => item.id === policy.userId); return <tr key={policy.id}><td><b>#{policy.id}</b></td><td><b>{policy.name}</b><small>{user?.email}</small></td><td>{policy.destination}</td><td>{policy.travelDate}</td><td>{policy.duration} days</td><td><b>₹{policy.premium}</b></td></tr>; })}</tbody></table></div> : <EmptyState icon={<FileText />} title="No policies issued yet" description="Issued policies will appear here." />}</AdminTablePage>; }
function AdminClaims({ store, updateStore, navigate, setToast }: { store: Store; updateStore: (patch: Partial<Store>) => void; navigate: (page: Page) => void; setToast: (message: string) => void }) { const setStatus = (id: string, status: Claim["status"]) => { updateStore({ claims: store.claims.map((claim) => claim.id === id ? { ...claim, status } : claim) }); setToast(`Claim #${id} marked ${status}.`); }; return <AdminTablePage title="Claims" eyebrow="ADMIN · REVIEW QUEUE" description="Review requests and update claim statuses." navigate={navigate}>{store.claims.length ? <div className="data-table-wrap"><table><thead><tr><th>Claim</th><th>Customer</th><th>Policy</th><th>Reason</th><th>Status</th><th>Update</th></tr></thead><tbody>{store.claims.map((claim) => { const user = store.users.find((item) => item.id === claim.userId); return <tr key={claim.id}><td><b>#{claim.id}</b><small>{claim.submitted}</small></td><td><b>{user?.name}</b><small>{user?.email}</small></td><td>#{claim.policyId}</td><td>{claim.reason}</td><td><span className={`status-chip ${claim.status.toLowerCase()}`}>{claim.status}</span></td><td><div className="status-actions"><button className="approve-button" onClick={() => setStatus(claim.id, "Approved")}><Check size={13} /> Approve</button><button className="reject-button" onClick={() => setStatus(claim.id, "Rejected")}><X size={13} /> Reject</button></div></td></tr>; })}</tbody></table></div> : <EmptyState icon={<TicketCheck />} title="No claims submitted yet" description="Customer claims will appear here for review." />}</AdminTablePage>; }
function AdminTablePage({ title, eyebrow, description, navigate, children }: { title: string; eyebrow: string; description: string; navigate: (page: Page) => void; children: ReactNode }) { return <section className="page-container table-page"><button className="back-link" onClick={() => navigate("admin")}>← Admin dashboard</button><div className="section-heading table-heading"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p>{description}</p></div></div>{children}</section>; }

function EmptyState({ icon, title, description, action, onClick }: { icon: ReactNode; title: string; description: string; action?: string; onClick?: () => void }) { return <div className="empty-state"><div className="empty-icon">{icon}</div><h3>{title}</h3><p>{description}</p>{action && onClick && <button className="button button-primary" onClick={onClick}>{action} <ArrowRight size={17} /></button>}</div>; }
function SiteFooter({ navigate }: { navigate: (page: Page) => void }) { return <footer className="site-footer"><div><Logo navigate={navigate} /><p>A complete digital travel insurance experience for modern journeys.</p></div><div className="footer-links"><span>Platform</span><button onClick={() => navigate("register")}>Get started</button><button onClick={() => navigate("admin-login")}>Admin access</button></div><div className="footer-bottom"><span>© 2026 Travel Insurance Policy Issuance Platform</span><span>Built for confident journeys.</span></div></footer>; }

export default App;
export { App };

export const PREMIUM_PER_DAY = 100;

export function calculatePremium(duration: number): number {
  if (!Number.isFinite(duration) || duration < 1) return 0;
  return Math.floor(duration) * PREMIUM_PER_DAY;
}

export function isValidTravelDuration(duration: number): boolean {
  return Number.isInteger(duration) && duration >= 1 && duration <= 365;
}

import { describe, expect, it } from "vitest";
import { calculatePremium, isValidTravelDuration } from "./travel";

describe("travel insurance business rules", () => {
  it("calculates the premium at 100 per travel day", () => {
    expect(calculatePremium(5)).toBe(500);
    expect(calculatePremium(14)).toBe(1400);
  });

  it("rejects empty, fractional, and out-of-range durations", () => {
    expect(isValidTravelDuration(0)).toBe(false);
    expect(isValidTravelDuration(2.5)).toBe(false);
    expect(isValidTravelDuration(366)).toBe(false);
    expect(isValidTravelDuration(30)).toBe(true);
  });
});
